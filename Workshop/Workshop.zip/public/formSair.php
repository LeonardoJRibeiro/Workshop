                <li class="nav-item">
                    <a id="sair" class="nav-link" href="">Sair</a>
                </li>
<script type="text/javascript">
    $(document).ready(function(){
        $("#sair").click(function (){
            $.post(" ",{sair : "sair"}, function(data, status){
                
            });
        });
    });
    </script>